// scripts/shard-run.js
'use strict';

(async () => {

const minimist = require('minimist');
const { fork, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { chromium } = require('playwright');

const { seedBuckets, appendToBuckets } = require('../src/discover/frontier');
const { makeLogger } = require('../src/utils/log');
const { sanitizePathPrefix } = require('../src/config');
const { parseCsv } = require('../src/io/csv');
const dedupe = (arr) => Array.from(new Set(arr || []));
if (typeof global.fetch !== 'function') {
  global.fetch = (...args) => import('node-fetch').then(({ default: f }) => f(...args));
}

// ----------------------- argv -----------------------
const argv = minimist(process.argv.slice(2), {
  boolean: ['keepPageParam','dropCache','rebuildLinks','open','headless','override'],
  string:  ['input','base','pathPrefix','excelDelimiter','followup','outDir','telemetryPort'],
  default: {
    pathPrefix: '/',
    excelDelimiter: 'comma',
    bucketParts: 1,
    shards: os.cpus().length,
    shardCap: 0,
    concurrency: 4,
    telemetryPort: process.env.TELEMETRY_PORT || 7077,
    open: true,
  }
});

// Resolve paths early so we can share with telemetry
const inputPath = argv.input ? path.resolve(String(argv.input)) : '';
const outDirAbs = path.resolve(String(argv.outDir || 'dist'));
const cfgPath = path.join(outDirAbs, 'telemetry', 'config.json');

try {
  const j = JSON.parse(fs.readFileSync(cfgPath,'utf8'));
  if (j && typeof j === 'object') {
    j.started = false;                       // force fresh preflight
    fs.mkdirSync(path.dirname(cfgPath), { recursive:true });
    fs.writeFileSync(cfgPath, JSON.stringify(j, null, 2));
  }
} catch {}



// Telemetry module (load BEFORE using it anywhere)
const tmod = require('../src/utils/telemetry');
const telemetry = tmod.telemetry || tmod;

console.log('[orchestrator] waiting for output selection in the web UI…');

// Let telemetry know what we’re launching with (for /preflight CSV sniffing)
if (typeof telemetry.setLaunchContext === 'function') {
  telemetry.setLaunchContext({ inputPath, outDir: outDirAbs });
}

function mergeManifestDedup(masterFile, outDir) {
  try {
    const txt = fs.existsSync(masterFile) ? fs.readFileSync(masterFile, 'utf8') : '';
    const urls = txt.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
    const unique = Array.from(new Set(urls));
    const out = path.join(outDir, 'urls-final.txt');
    fs.writeFileSync(out, unique.join('\n') + '\n', 'utf8');
    return unique.length;
  } catch (e) {
    console.warn('[merge warn]', e && e.message ? e.message : e);
    return 0;
  }
}


// -------------------- start telemetry --------------------
const requestedPort = Number(argv.telemetryPort || process.env.TELEMETRY_PORT || 7077);
const TELEMETRY_PORT = telemetry.startServer({ port: requestedPort, autoOpen: !!argv.open }) || requestedPort;
process.env.TELEMETRY_PORT = String(TELEMETRY_PORT);

// Optional: spawn Electron shell around the telemetry UI
// Optional: spawn Electron shell around the telemetry UI (robust on Windows/mac/Linux)
if (argv['spawn-electron']) {
  try {
    const electronPath = require('electron');
    const mainJs = path.resolve(__dirname, '../electron/main.js');

    const child = spawn(
      electronPath,
      [mainJs, '--telemetry-port', String(TELEMETRY_PORT)],
      {
        stdio: 'ignore',              // no inherited console
        detached: false,              // detached on Win with ignored stdio can cause EINVAL
        env: { ...process.env, TELEMETRY_PORT: String(TELEMETRY_PORT) }
      }
    );

    // unref only if available; harmless otherwise
    if (typeof child.unref === 'function') child.unref();
    console.log('[orchestrator] launched Electron UI');
  } catch (e) {
    console.error('[orchestrator] failed to launch Electron UI:', e && e.message ? e.message : e);
    // Fallback: open in default browser so you can keep working
    try {
      const url = `http://127.0.0.1:${TELEMETRY_PORT}/`;
      require('child_process').spawn(
        process.platform === 'win32' ? 'cmd' : 'xdg-open',
        process.platform === 'win32' ? ['/c', 'start', '', url] :
        (process.platform === 'darwin' ? [url] : [url]),
        { stdio: 'ignore', detached: true }
      );
      console.log('[orchestrator] opened telemetry in default browser as a fallback');
    } catch {}
  }
}



  function readConfigFile() {
    try { return JSON.parse(fs.readFileSync(cfgPath, 'utf8')); } catch { return null; }
  }

// wait loop in shard-run.js
async function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }
async function stopRequested() {
  const port = Number(process.env.TELEMETRY_PORT || 0);
  if (!port) return false;
  try {
    const r = await fetch(`http://127.0.0.1:${port}/stop-state`, { cache: 'no-store' });
    if (!r.ok) return false;
    const j = await r.json();
    return !!(j && j.stop);
  } catch { return false; }
}

console.log('[orchestrator] waiting for output selection in the web UI…');

// —— START GATE ————————————————————————————————————————————————
// Do not seed/spawn until the UI has explicitly Applied & Started
await telemetry.waitForApplyAndStart();
console.log('[orchestrator] Apply & Start received — proceeding…');
if (await stopRequested()) {
   console.log('[orchestrator] stop requested — exiting before configuring');
   return;
 }
// —— END START GATE ————————————————————————————————————————————————



while (true) {
  if (await stopRequested()) {
    console.log('[orchestrator] stop requested — exiting before start');
    return;
  }
  try {
    const r = await fetch(`http://127.0.0.1:${TELEMETRY_PORT}/preflight`, { cache: 'no-store' });
    if (!r.ok) throw 0;
    const j = await r.json();
    if (Array.isArray(j.outputs) && j.outputs.length) {
      if (j.started === true) {
        process.env.META_ONLY_REPORTS = j.outputs.join(',');
        const m = j.meta || {};
        var __preflightShape = j.shape || null;

        if (m.base) argv.base = m.base;
        if (m.prefix != null) argv.pathPrefix = m.prefix;
        if (m.outDir) argv.outDir = m.outDir;
        if (typeof m.keepPageParam === 'boolean') argv.keepPageParam = m.keepPageParam;

        // NEW: prod + maxShards
        if (typeof m.prod === 'boolean') argv.prod = m.prod;
        if (typeof m.maxShards === 'boolean') argv.maxShards = m.maxShards;

        if (+m.shards > 0) argv.shards = +m.shards;
        if (+m.bucketParts > 0) argv.bucketParts = +m.bucketParts;
        if (m.inputPath) argv.input = m.inputPath;

        if (typeof m.headless === 'boolean') {
          process.env.PLAYWRIGHT_HEADLESS = m.headless ? '1' : '';
        }
        break;
      }
    }
  } catch {}
  await sleep(300);
}

//Keep!!!
const cfg = {
  base: argv.base,
  pathPrefix: sanitizePathPrefix(argv.pathPrefix || ''),
  keepPageParam: (argv.keepPageParam === true || argv.keepPageParam === 'true'),
  shards: Math.min(+argv.shardCap || Infinity, Math.max(1, +argv.shards || os.cpus().length)),
  outDir: path.resolve(String(argv.outDir || 'dist')),
  childEntry: path.resolve('src/index.js'),
  input: argv.input || 'input.csv',
};


// --- Apply "maxShards" if requested by UI
if (argv.maxShards === true || String(argv.maxShards) === 'true') {
  cfg.shards = Math.max(1, os.cpus().length);
}

// buckets: 2*shards if shards>1, else 1 (unless explicitly provided)
let bucketParts = Number(argv.bucketParts || 0);
if (!bucketParts) bucketParts = (cfg.shards > 1 ? (2 * cfg.shards) : 1);

// … later, AFTER you read and apply meta overrides from telemetry/config.json …
{
  const _bp = Number(argv.bucketParts);
  if (_bp && Number.isFinite(_bp) && _bp > 0) {
    bucketParts = Math.floor(_bp);
  } else {
    bucketParts = (cfg.shards > 1 ? (2 * cfg.shards) : 1);
  }
}

console.log('[orchestrator] bucketParts (final):', bucketParts);

// --- Prod (safe) mode policy
if (argv.prod === true || String(argv.prod) === 'true') {
  // Lower pressure:
  //  - reduce child concurrency to 1
  //  - optional: cap shards to half the CPUs (min 1)
  //  - add a global polite delay for frontier claims (used by frontier.js)
  cfg.shards = 1;                 // prod = single shard
  argv.concurrency = 1;           // and single-page concurrency
  process.env.MC_POLITE_DELAY_MS = process.env.MC_POLITE_DELAY_MS || '750';
  process.env.MC_USER_AGENT = process.env.MC_USER_AGENT || 'MetaChecker/1.0 (safe mode; contact=you@example.com)';
  bucketParts = 1;                // one bucket
  // also force page-level concurrency 1 in children below
  argv.concurrency = 1;
}

//debug log to confirm everything
console.log('[orchestrator] final meta:', {
  base: cfg.base,
  pathPrefix: cfg.pathPrefix,
  outDir: cfg.outDir,
  shards: cfg.shards,
  bucketParts,
  keepPageParam: cfg.keepPageParam,
  prod: !!argv.prod,
  maxShards: !!argv.maxShards,
  input: argv.input || ''
});



// optional: start the terminal TUI that reads dist/telemetry/state.json
if (!process.env.NO_VIZ) try {
  const tui = spawn(process.execPath, [path.resolve(__dirname, 'viz-tui.js'), outDirAbs], {
    stdio: 'inherit',
    env: { ...process.env, TELEMETRY_PORT: String(TELEMETRY_PORT) }
  });
  console.log(`[orchestrator] viz-tui started (port ${TELEMETRY_PORT})`);
  tui.on('exit', (code) => console.log(`[orchestrator] viz-tui exited ${code}`));
} catch (e) {
  console.warn('[orchestrator] failed to launch viz-tui:', e && e.message ? e.message : e);
}

// --- keep your viz-tui try/catch above as-is ---

function parseFirstColumn(filePath) {
  try {
    if (!filePath) return { urls: [], explicit: false };
    const rows = parseCsv(filePath, 'auto');
    const firstCell = (row) => Array.isArray(row)
      ? String(row[0] ?? '')
      : row && typeof row === 'object'
        ? String(row[Object.keys(row)[0]] ?? '')
        : '';
    const first = rows.map(firstCell).map(s => s.trim()).filter(Boolean);
    const looksUrl = (s) => /^https?:\/\//i.test(s);
    const good = first.filter(looksUrl);
    return { urls: Array.from(new Set(good)), explicit: first.length > 0 && (good.length / first.length) >= 0.8 };
  } catch {
    return { urls: [], explicit: false };
  }
}

// ---- apply Control Panel meta overrides from telemetry/config.json ----
const file = readConfigFile() || { meta:{} };
const meta = file.meta || {};

// allow UI to override CLI (when provided)
if (typeof meta.base === 'string' && meta.base)                 argv.base = meta.base;
if (typeof meta.prefix === 'string')                            argv.pathPrefix = meta.prefix;
if (typeof meta.outDir === 'string' && meta.outDir)             argv.outDir = meta.outDir;
if (typeof meta.keepPageParam === 'boolean')                    argv.keepPageParam = meta.keepPageParam;
if (typeof meta.shards === 'number' && meta.shards > 0)         argv.shards = meta.shards;
if (typeof meta.bucketParts === 'number' && meta.bucketParts > 0) argv.bucketParts = meta.bucketParts;

// let telemetry know what we're launching (for /preflight CSV sniffing, etc.)
(tmod.setLaunchContext || (()=>{}))({
  inputPath,
  outDir: cfg.outDir,
  base: cfg.base || '',
  pathPrefix: String(argv.pathPrefix || ''),
  bucketParts: Number(bucketParts || 1),
  shardCap: Number(argv.shardCap || cfg.shards || 1),
  concurrency: Number(argv.concurrency || 1),
});

// now proceed…
const T0 = Date.now();

telemetry.setStepper(['seed-scan','bootstrap-frontier','spawn-workers','merge-urls','dedupe','cleanup','done'], 0);
telemetry.step(0);

if (!cfg.base) { console.error('✖ Missing required flag: --base'); process.exit(1); }
fs.mkdirSync(cfg.outDir, { recursive: true });


const origin   = new URL(cfg.base).origin;
const prefix   = String(cfg.pathPrefix || '').replace(/^["']|["']$/g, '').replace(/\/+$/, '');
const followup = String(argv.followup || 'none').toLowerCase();

const sniff = parseFirstColumn((argv.input && String(argv.input)) || inputPath || '');
  try {
    const inputActual = (argv.input && String(argv.input)) || inputPath || '';
    if (inputActual) {
      let firstLine = '';
      try {
        const raw = fs.readFileSync(inputActual, 'utf8');
        firstLine = (raw.split(/\r?\n/).find(l => l.trim().length) || '').slice(0, 400);
      } catch {}

      const previewUrl = (sniff.urls && sniff.urls[0]) ? sniff.urls[0] : '';

      telemetry.threadStatus({
        workerId: 0,
        phase: 'input-confirm',
        status: 'ok',
        url: previewUrl ? `First URL: ${previewUrl}` : `Input: ${path.basename(inputActual)}`,
        firstLine
      });

      telemetry.event({ type: 'input/preview', file: path.basename(inputActual), firstLine });
    } else {
      telemetry.threadStatus({ workerId: 0, phase: 'input-confirm', url: 'No input file selected (discovery-only)' });
    }
  } catch {}


const sitemapMode =
  !!(__preflightShape &&
     __preflightShape.exists === true &&
     __preflightShape.cols === 3 &&
     Array.isArray(__preflightShape.inferredRoles) &&
     __preflightShape.inferredRoles[0] === 'url');
telemetry.event({
  type: 'mode',
  sitemapMode,
  urlCount: sniff.urls.length,
  explicit: sniff.explicit
});

const log = makeLogger({ shardIndex: 'orchestrator', shards: cfg.shards });
console.log(`[orchestrator] ${new Date().toLocaleTimeString()} CPU=${os.cpus().length} → shards=${cfg.shards}`, {});


  // Common outputs
  const master = path.join(cfg.outDir, 'urls-final.txt');
  for (const f of fs.readdirSync(cfg.outDir)) {
    if (/^urls-final\.part\d+\.json$/i.test(f)) {
      try { fs.unlinkSync(path.join(cfg.outDir, f)); } catch {}
    }
  }


  // ============== 3-col sitemap mode (explicit list) ==============
  if (sitemapMode) {
    console.log('[orchestrator] 3-column input detected → using first column as explicit URL list; skipping discovery.');
    // normalize to absolute within site + optional pathPrefix filter
    const normalized = dedupe(sniff.urls.map(h => {
      try {
        const u0 = new URL(h, origin);
        if (u0.origin !== origin) return null;
        const u = new URL(u0.pathname + u0.search, origin).toString().replace(/\/+$/, '');
        if (prefix && !u0.pathname.startsWith(prefix)) return null;
        return u;
      } catch { return null; }
    }).filter(Boolean));

    // write the explicit list to a single source file
    const urlsFile = path.join(cfg.outDir, `urls-final.source.json`);
    fs.writeFileSync(urlsFile, JSON.stringify(normalized, null, 0), 'utf8');

    telemetry.step('spawn-workers');

    // fan out across N shards; each child slices via --shards/--shardIndex
    const parts = cfg.shards;
    let finished = 0;

    const children = new Set();
    for (let i = 0; i < parts; i++) {
      if (await stopRequested()) break;
      const partOut = path.join(cfg.outDir, `urls-final.part${i + 1}.json`);
      const childArgs = [
        cfg.childEntry,
        '--base', cfg.base,
        '--concurrency', String(argv.concurrency || 4),
        '--keepPageParam', String(cfg.keepPageParam),
        '--outDir', cfg.outDir,
        '--input', argv.input || 'input.csv',
        '--rebuildLinks', argv.rebuildLinks ? 'true' : 'false',
        '--dropCache',   argv.dropCache   ? 'true' : 'false',
        '--headless', (process.env.PLAYWRIGHT_HEADLESS ? 'true' : 'false'),
        '--mode', 'root-urls',
        '--urlsFile', urlsFile,
        '--pathPrefix', prefix || '/',
        '--workerId', String(i + 1),
        '--workerTotal', String(parts),
        '--urlsOutFile', partOut,
        '--shards', String(parts),
        '--shardIndex', String(i + 1),
      ];

      console.log('[orchestrator] spawn root-urls', childArgs.slice(1).join(' '));
      telemetry.threadStatus({ workerId: i + 1, phase: 'spawn:root-urls', url: '' });

      const child = fork(childArgs[0], childArgs.slice(1), {
        stdio: 'inherit',
        env: { ...process.env, TELEMETRY_PORT: String(TELEMETRY_PORT) }
      });
      const killer = setInterval(async () => {
        if (await stopRequested()) {
          try { child.kill('SIGINT'); } catch {}
        }
      }, 500);
      children.add(child);
      child.on('exit', async (code) => {
        clearInterval(killer);
        children.delete(child);
        finished++;
        telemetry.threadStatus({ workerId: i + 1, phase: 'exit:root-urls', done: true, code });
        if (code !== 0) console.error(`Error: worker for root-urls shard ${i+1}/${parts} exited ${code}`);

        // append this shard’s output
        try {
          if (fs.existsSync(partOut)) {
            const urls = JSON.parse(fs.readFileSync(partOut, 'utf8'));
            fs.appendFileSync(master, urls.map(u => `${u}\n`).join(''), 'utf8');
            console.log('[append]', path.basename(partOut), '→', path.relative(process.cwd(), master), `(+${urls.length})`);
          }
        } catch (e) {
          console.warn('[append warn]', String(e && e.message ? e.message : e));
        }

        if (await stopRequested()) {
          for (const c of children) { try { c.kill('SIGINT'); } catch {} }
          console.log('[orchestrator] stop requested — halting sitemap mode');
          return; // leaves telemetry running; user can New Run
}

        if (finished === parts) await finalizeSitemap();
      });
      
    }

    async function finalizeSitemap() {
      telemetry.step('merge-urls');
      const uniqueCount = mergeManifestDedup(master, cfg.outDir);
      telemetry.bump('urlsFound', uniqueCount);

      // Merge existence & working/not-working parts (3-col mode)
      try {
        // working/not-working .part*.txt -> merged .txt
        const collectTxt = (re) =>
          fs.readdirSync(cfg.outDir)
            .filter(f => re.test(f))
            .flatMap(f => fs.readFileSync(path.join(cfg.outDir, f), 'utf8').split(/\r?\n/).filter(Boolean));
        const uniqLines = (arr) => Array.from(new Set(arr));

        const workingAll = uniqLines(collectTxt(/^working-urls\.part\d+\.txt$/i));
        const notWorkingAll = uniqLines(collectTxt(/^not-working-urls\.part\d+\.txt$/i));

        if (workingAll.length) {
          fs.writeFileSync(path.join(cfg.outDir, 'working-urls.txt'), workingAll.join('\n') + '\n', 'utf8');
          console.log('[merge] working-urls.txt', workingAll.length);
        }
        if (notWorkingAll.length) {
          fs.writeFileSync(path.join(cfg.outDir, 'not-working-urls.txt'), notWorkingAll.join('\n') + '\n', 'utf8');
          console.log('[merge] not-working-urls.txt', notWorkingAll.length);
        }

        // url-existence.part*.csv -> url-existence.csv
        const csvParts = fs.readdirSync(cfg.outDir).filter(f => /^url-existence\.part\d+\.csv$/i.test(f));
        if (csvParts.length) {
          const all = [];
          for (const f of csvParts) {
            const lines = fs.readFileSync(path.join(cfg.outDir, f), 'utf8').split(/\r?\n/).filter(Boolean);
            all.push(lines);
          }
          const header = all[0][0];
          const body = new Set(all.flatMap(lines => lines.slice(1)));
          fs.writeFileSync(
            path.join(cfg.outDir, 'url-existence.csv'),
            [header, ...Array.from(body)].join('\n') + '\n',
            'utf8'
          );
          console.log('[merge] url-existence.csv', body.size);
        }

        // url-existence.part*.json -> url-existence.json
        const jsonParts = fs.readdirSync(cfg.outDir).filter(f => /^url-existence\.part\d+\.json$/i.test(f));
        if (jsonParts.length) {
          const map = new Map();
          for (const f of jsonParts) {
            const arr = JSON.parse(fs.readFileSync(path.join(cfg.outDir, f), 'utf8'));
            for (const row of arr) map.set(row.input_url, row);
          }
          const merged = Array.from(map.values());
          fs.writeFileSync(
            path.join(cfg.outDir, 'url-existence.json'),
            JSON.stringify(merged, null, 0),
            'utf8'
          );
          console.log('[merge] url-existence.json', merged.length);

        }
      } catch (e) {
        console.warn('[merge warn]', String(e && e.message ? e.message : e));
      }

      telemetry.step('cleanup');
      const shouldClean = argv.cleanArtifacts !== 'false'; // default true
      if (shouldClean) {
        const out = cfg.outDir;
        const rm = (p) => { try { fs.rmSync(p, { recursive: true, force: true }); console.log('[clean]', path.relative(process.cwd(), p)); } catch (e) { console.warn('[clean warn]', e.message); } };
        for (const f of fs.readdirSync(out)) if (/^urls-final\.part\d+\.json$/i.test(f)) rm(path.join(out, f));
        rm(path.join(out, 'frontier'));
        rm(path.join(out, 'disco-locks'));
        rm(path.join(out, 'locks'));
        rm(path.join(out, 'frontier.ndjson'));
        if (argv.dropCache === true || argv.dropCache === 'true') {
          try { for (const f of fs.readdirSync(out)) if (/^site_catalog\.part\d+\.json$/i.test(f)) rm(path.join(out, f)); } catch {}
        }
      }

      telemetry.step('done');
      const MS = Date.now() - T0;
      const HH = Math.floor(MS/3600000);
      const MM = Math.floor((MS%3600000)/60000);
      const SS = Math.floor((MS%60000)/1000);
      console.log(`[orchestrator] done in ${HH}h ${MM}m ${SS}s (${MS.toLocaleString()} ms)`);
      // Wait for reset, then allow another run
      try { if (global.__mc_visibleBrowser) { await global.__mc_visibleBrowser.close(); global.__mc_visibleBrowser = null; } } catch {}
      await waitForResetThenPreflight();
      return;
    }

    return;
  }

  // ============== Discovery path (bucketed frontier) ==============
  const frontierDir  = path.join(cfg.outDir, 'frontier');
  const discoLocks   = path.join(cfg.outDir, 'disco-locks');
  // Clean previous discovery artifacts to avoid stale .offset / owner files
  try { fs.rmSync(frontierDir, { recursive: true, force: true }); } catch {}
  try { fs.rmSync(discoLocks, { recursive: true, force: true }); } catch {}
  fs.mkdirSync(frontierDir, { recursive: true });
  fs.mkdirSync(discoLocks, { recursive: true });

  // Canonical seeds (both with/without trailing slash to avoid strict prefix filters)
  const rawPrefix = String(cfg.pathPrefix || '').replace(/^["']|["']$/g,'') || '/';
  const normPrefixNoSlash = rawPrefix === '/' ? '/' : rawPrefix.replace(/\/+$/,'');
  const normPrefixSlash   = normPrefixNoSlash === '/' ? '/' : (normPrefixNoSlash + '/');
 const seedNoSlash = new URL(normPrefixNoSlash, cfg.base).toString();
  const seedSlash   = new URL(normPrefixSlash,   cfg.base).toString();
  // De-duplicate but guarantee we have at least one seed line
  const canonicalSeeds = Array.from(new Set([seedNoSlash, seedSlash].map(u => u.replace(/#.*$/,''))));

  seedBuckets(frontierDir, canonicalSeeds, bucketParts);
  // DEBUG: show a safe peek so we can confirm we truly wrote URL lines (not just CRLF)
  try {
    const bucket0 = path.join(frontierDir, `bucket.0.ndjson`);
    const sample  = fs.existsSync(bucket0) ? fs.readFileSync(bucket0,'utf8').split(/\r?\n/).slice(0,3) : [];
    console.log('[frontier] seed sample bucket.0.ndjson →', sample);
  } catch {}


  function safeURL(u) {
    let s = String(u || '').trim();
    if (!s) throw new Error('Base URL is empty');
    if (!/^[a-z]+:\/\//i.test(s)) s = 'https://' + s;
    return new URL(s);
  }

  // --- 1) seed-scan to discover first-level sections ---
  const baseHost= safeURL(meta.base);
  const etld1 = (host) => host.split('.').slice(-2).join('.'); // good enough for ping.com
  const sameSite = (u) => etld1(u.hostname) === etld1(baseHost);

  const sectionKeyFromPathname = (pn) => {
    const rest = prefix && pn.startsWith(prefix) ? pn.slice(prefix.length) : pn;
    const seg = rest.split('/').filter(Boolean)[0];
    return seg || ''; // '' means "root under /en-us"
  };

  const seedUrl = new URL(prefix || '/', cfg.base).toString();

  if (await stopRequested()) {
    telemetry.step('done');
    console.log('[orchestrator] stop requested — exiting before seed-scan');
    return;
  }


  telemetry.step('seed-scan');
  try { telemetry.threadStatus({ pid: process.pid, phase: 'seed-scan', url: seedUrl }); } catch {}
  console.log(`[orchestrator] seed-scan ${seedUrl} to find first-level sections…`);
  const browser = await chromium.launch({
    headless: process.env.PLAYWRIGHT_HEADLESS === '1',
    args: ['--disable-dev-shm-usage']
  });
  const context = await browser.newContext({
    ignoreHTTPSErrors: true,
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119 Safari/537.36',
    locale: 'en-US'
  });
  context.setDefaultNavigationTimeout(30000);
  context.setDefaultTimeout(10000);

  await context.route('**/*', (route) => {
    const u = route.request().url();
    if (/\.(png|jpe?g|gif|webp|svg|ico|woff2?|ttf|otf|mp4|webm|avi|mov)(\?|$)/i.test(u)) return route.abort();
    if (/(googletagmanager|google-analytics|doubleclick|facebook|segment|mixpanel|hotjar)\./i.test(u)) return route.abort();
    return route.continue();
  });

  let sections = [];
  let rootUrls = [];
  let filtered = [];

  try {
    const page = await context.newPage();

    // retry seed navigation up to 3 times with exponential backoff
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        await page.goto(seedUrl, { waitUntil: 'domcontentloaded', timeout: 30000, referer: cfg.base });
        break;
      } catch (e) {
        if (attempt === 3) throw e;
        await page.waitForTimeout(800 * attempt);
      }
    }
    try { await page.waitForLoadState('networkidle', { timeout: 3000 }); } catch {}

    // lightweight “reveal”
    const clickMs = 120, hoverMs = 120;
    const clickSafe = async (h) => { try { await h.click({ timeout: 500 }); await page.waitForTimeout(clickMs); } catch {} };
    const hoverSafe = async (h) => { try { await h.hover({ timeout: 500 }); await page.waitForTimeout(hoverMs); } catch {} };
    const menuButtons = await page.$$(
      'button[aria-expanded="false"],button[aria-controls],' +
      '[role="button"][aria-expanded="false"],[data-toggle],[data-action*="menu"],[data-action*="expand"]'
    );
    for (const btn of menuButtons.slice(0, 20)) await clickSafe(btn);
    const hoverables = await page.$$(
      'nav [aria-haspopup="true"], nav .dropdown, nav .menu, .nav [aria-expanded]'
    );
    for (const el of hoverables.slice(0, 32)) await hoverSafe(el);
    try { await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight)); } catch {}
    await page.waitForTimeout(200);

    const links = await page.evaluate(() => {
      const toAbs = (h) => { try { return new URL(h, location.href).href; } catch { return ''; } };
      const bad = /^(javascript:|mailto:|tel:|data:)/i;
      const fromOnclick = (code) => {
        if (!code) return '';
        const m =
          code.match(/(?:window\.open|location\.assign|location\.replace)\(\s*['"]([^'"]+)['"]\s*\)/i) ||
          code.match(/(?:window\.location|location)\s*=\s*['"]([^'"]+)['"]/i) ||
          code.match(/location\.href\s*=\s*['"]([^'"]+)['"]/i);
        return m ? m[1] : '';
      };

      const nodes = Array.from(document.querySelectorAll(
        'a[href], [role="link"], button, [role="button"], [data-href], [data-url], [onclick]'
      ));
      const out = [];
      for (const el of nodes) {
        if (el.hasAttribute('href')) {
          const raw = el.getAttribute('href') || '';
          if (!raw || bad.test(raw)) continue;
          out.push(toAbs(raw.split('#')[0]));
        } else if (el.hasAttribute('data-href') || el.hasAttribute('data-url')) {
          const raw = el.getAttribute('data-href') || el.getAttribute('data-url') || '';
          if (!raw || bad.test(raw)) continue;
          out.push(toAbs(raw.split('#')[0]));
        } else if (el.hasAttribute('onclick')) {
          const dest = fromOnclick(el.getAttribute('onclick') || '');
          if (dest && !bad.test(dest)) out.push(toAbs(dest.split('#')[0]));
        }
      }
      return out;
    });

    filtered = links.map(href => {
      try {
        const u = new URL(href);
        if (!sameSite(u)) return null;
        const n = new URL(u.pathname + u.search, origin);
        return n.toString();
      } catch { return null; }
    }).filter(Boolean).filter(href => {
      try { const u = new URL(href); return !prefix || u.pathname.startsWith(prefix); }
      catch { return false; }
    });

    const secSet = new Set();
    for (const href of filtered) {
      const pn = new URL(href).pathname;
      const key = sectionKeyFromPathname(pn);
      if (key) secSet.add(key);
      else rootUrls.push(new URL(href).toString().split('#')[0]);
    }
    sections = Array.from(secSet);
    rootUrls = dedupe(rootUrls);
  } catch (e) {
    console.warn('[orchestrator] seed-scan failed, continuing with root-only crawl:', String(e && e.message ? e.message : e));
    sections = [];
    rootUrls = [seedUrl];
    filtered = [];
  } finally {
    try { await context.close(); } catch {}
    if (process.env.PLAYWRIGHT_HEADLESS === '1') {
     try { await browser.close(); } catch {}
   } else {
     global.__mc_visibleBrowser = browser;
   }
  }


  if (!sections.length && !rootUrls.length) rootUrls = [seedUrl];

  console.log(`[orchestrator] sections found: ${sections.length} ${JSON.stringify(sections.slice(0, 20))}${sections.length>20?'…':''}`);
  if (rootUrls.length) console.log(`[orchestrator] root URLs under ${prefix}: ${rootUrls.length}`);

  // --- bootstrap frontier ---
  const sectionUrls = sections.map(s => new URL(`${prefix}/${s}`.replace(/\/+/g,'/'), cfg.base).toString());
  const bootstrapSeeds = Array.from(new Set([seedUrl, ...rootUrls, ...sectionUrls, ...filtered]));
  if (bootstrapSeeds.length) {
    appendToBuckets(frontierDir, bootstrapSeeds, bucketParts);
    // Announce bucket ownership/initial progress so the Buckets panel isn't empty
    try {
      // Accept either "bucket.N.ndjson" or "bucket-N.ndjson"
      const files = fs.readdirSync(frontierDir).filter(f => /^bucket[.-]\d+\.ndjson$/i.test(f));
      // NEW: sanity log of per-bucket line counts so we can see if frontier is truly empty
      const lineCount = (p) => {
        try { return (fs.readFileSync(p, 'utf8').match(/\n/g) || []).length; } catch { return 0; }
      };
      const counts = files
        .map(f => [f, lineCount(path.join(frontierDir, f))])
        .sort((a,b) => a[0].localeCompare(b[0]));
      console.log('[frontier] bucket files:', counts.map(([f,c]) => `${f}:${c}`).join(', '));
      const totalLines = counts.reduce((n, [,c]) => n + c, 0);

        // Keep the friendly warning
        if (totalLines === 0) {
          console.warn('[frontier] WARNING: all buckets are empty after seeding — workers will exit immediately.');
        }

        // Extra peek: print the very first non-empty line we see in the first bucket
      try {
        const first = files.sort()[0];
        if (first) {
          const p = path.join(frontierDir, first);
          const txt = fs.readFileSync(p,'utf8');
          const firstLine = (txt.split(/\r?\n/).map(s => s.trim()).filter(Boolean)[0] || '');
          if (firstLine) {
            console.log('[frontier] first line sample:', firstLine);
          } else {
            console.warn('[frontier] first line sample is empty (only blank lines present)');
          }
        }
      } catch {}

        // NEW: hard-stop if literally every bucket has 0 lines (avoid “done with no work” confusion)
        if (counts.every(([, c]) => c === 0)) {
          console.warn('[frontier] No work after seeding — check base/prefix/bucketParts. Aborting run.');
          telemetry.event({ type: 'error', msg: 'No work after seeding (0 lines in all buckets).' });
          telemetry.step('done');
          try {
            if (global.__mc_visibleBrowser) { await global.__mc_visibleBrowser.close(); global.__mc_visibleBrowser = null; }
          } catch {}
          await waitForResetThenPreflight();
          return;
        }
      for (const f of files) {
      const m = f.match(/bucket[.-](\d+)\.ndjson/i);
        if (!m) continue;
        const r = Number(m[1]);
        // owner "none" at bootstrap, 0 processed/pending unknown (UI will update when workers claim)
        if (telemetry.bucketOwner) telemetry.bucketOwner(r, 'none');
        if (telemetry.bucketProgress) telemetry.bucketProgress(r, 0, 0);
      }
    } catch {}

    telemetry.step('bootstrap-frontier');
    console.log('[orchestrator] bootstrap frontier +', bootstrapSeeds.length, 'seeds');
    // Sanity: log per-bucket line counts and show a sample line so we know
  try {
    const files = fs.readdirSync(frontierDir).filter(f => /^bucket\.\d+\.ndjson$/i.test(f));
    const lineCount = (p) => {
      try { return (fs.readFileSync(p, 'utf8').match(/\n/g) || []).length; } catch { return 0; }
    };
   const counts = files.map(f => [f, lineCount(path.join(frontierDir, f))]).sort((a,b)=>a[0].localeCompare(b[0]));
    console.log('[frontier] bucket files:', counts.map(([f,c]) => `${f}:${c}`).join(', '));
    const first = files.sort()[0];
    if (first) {
      const txt = fs.readFileSync(path.join(frontierDir, first), 'utf8');
      const firstLine = (txt.split(/\r?\n/).map(s => s.trim()).filter(Boolean)[0] || '');
      console.log('[frontier] first line sample:', firstLine || '(empty)');
    }
  } catch {}

  }


  // --- tasks: N frontier workers ---
  const parts = cfg.shards;
  const children = new Set();
  const tasks = Array.from({ length: parts }, (_, i) => ({
    kind: 'frontier',
    workerId: i + 1,
    argv: [
      '--mode', 'frontier',
      '--pathPrefix', String(cfg.pathPrefix||'').replace(/^["']|["']$/g,''),
      '--frontierDir', frontierDir,
      '--discoLocks', discoLocks,
      '--partIndex', String(i),
      '--partTotal', String(parts),
      '--bucketParts', String(bucketParts),
      '--bucketPattern', 'dot',
      '--workerId', String(i + 1),
      '--workerTotal', String(parts),
      '--urlsOutFile', path.join(cfg.outDir, `urls-final.part${i+1}.json`),
    ]
  }));


  // optional: section follow-up
  if (followup === 'sections' && sections.length) {
    let partCounter = parts;
    for (const sec of sections) {
      partCounter++;
      const sectionPrefix = `${prefix}/${sec}`.replace(/\/+/g, '/');
      const urlsOutFile = path.join(cfg.outDir, `urls-final.part${partCounter}.json`);
      tasks.push({
      kind: 'section', section: sec, workerId: partCounter, argv: [
        '--mode', 'frontier',
        '--pathPrefix', sectionPrefix,
        '--frontierDir', frontierDir,
        '--discoLocks', discoLocks,
        '--bucketParts', String(bucketParts),
        '--partIndex', String(0),
        '--partTotal', String(1),
        '--urlsOutFile', urlsOutFile,
        '--workerId', String(partCounter),
        '--workerTotal', String(sections.length + parts),
      ]
    });
    }
  }

  telemetry.step('spawn-workers');

  // --- pool ---
  const maxParallel = Math.min(cfg.shards, tasks.length);
  let running = 0, idx = 0;

  async function launchNext() {
    if (await stopRequested()) {
      console.log('[orchestrator] stop requested — not launching new tasks');
      return;
    }
    if (idx >= tasks.length) return;
    const t = tasks[idx++];
    running++;

    const childArgs = [
    cfg.childEntry,
    '--base', cfg.base,
    '--input', argv.input || 'input.csv',
    '--headless', (process.env.PLAYWRIGHT_HEADLESS ? 'true' : 'false'),
    '--concurrency', String(argv.concurrency || 4),
    '--keepPageParam', String(cfg.keepPageParam),
    '--outDir', cfg.outDir,
    '--rebuildLinks', argv.rebuildLinks ? 'true' : 'false',
    '--dropCache',   argv.dropCache   ? 'true' : 'false',
    ...t.argv
  ];

    console.log('[orchestrator] spawn', t.kind, t.section ? t.section : '', childArgs.slice(1).join(' '));
    telemetry.threadStatus({ workerId: t.workerId, phase: `spawn:${t.kind}`, url: t.section || '' });


    const child = fork(childArgs[0], childArgs.slice(1), {
      stdio: 'inherit',
      env: { ...process.env, TELEMETRY_PORT: String(TELEMETRY_PORT) }
    });
    const killer = setInterval(async () => {
      if (await stopRequested()) {
        try { child.kill('SIGINT'); } catch {}
      }
    }, 500);
    children.add(child);

    child.on('exit', async (code) => {
      clearInterval(killer);
      children.delete(child);
      running--;
      telemetry.threadStatus({ workerId: t.workerId, phase: `exit:${t.kind}`, done: true, code });
      if (code !== 0) console.error(`Error: worker for ${t.kind}${t.section?`:${t.section}`:''} exited ${code}`);

      // Append this worker's URLs
      try {
          const outArgIdx = t.argv.findIndex(a => a === '--urlsOutFile');
          const fileArgIdx = t.argv.findIndex(a => a === '--urlsFile');
          const file = outArgIdx >= 0 ? t.argv[outArgIdx + 1]
                    : fileArgIdx >= 0 ? t.argv[fileArgIdx + 1]
                          : null;
        if (file && fs.existsSync(file)) {
          const urls = JSON.parse(fs.readFileSync(file, 'utf8'));
          fs.appendFileSync(master, urls.map(u => `${u}\n`).join(''), 'utf8');
          console.log('[append]', path.basename(file), '→', path.relative(process.cwd(), master), `(+${urls.length})`);
        }
      } catch (e) {
        console.warn('[append warn]', String(e && e.message ? e.message : e));
      }

      if (await stopRequested()) {
        // stop wins immediately: don’t enqueue more work and don’t merge
        for (const c of children) { try { c.kill('SIGINT'); } catch {} }
        telemetry.step('done');
        console.log('[orchestrator] stop requested — halted');
        try { if (global.__mc_visibleBrowser) { await global.__mc_visibleBrowser.close(); global.__mc_visibleBrowser = null; } } catch {}
        await waitForResetThenPreflight();
        return;
      } else if (idx < tasks.length) {
        // keep the pool fed
        launchNext();
      } else if (running === 0) {
        // finalize the run
        telemetry.step('merge-urls');
        const uniqueCount = mergeManifestDedup(master, cfg.outDir);
        telemetry.bump('urlsFound', uniqueCount);

        console.log('[orchestrator] done');

        telemetry.step('cleanup');
        const shouldClean = argv.cleanArtifacts !== 'false'; // default true
        if (shouldClean) {
          const out = cfg.outDir;
          const rm = (p) => { try { fs.rmSync(p, { recursive: true, force: true }); console.log('[clean]', path.relative(process.cwd(), p)); } catch (e) { console.warn('[clean warn]', e.message); } };

          for (const f of fs.readdirSync(out)) {
            if (/^urls-final\.part\d+\.json$/i.test(f)) rm(path.join(out, f));
          }

          rm(path.join(out, 'frontier'));
          rm(path.join(out, 'disco-locks'));
          rm(path.join(out, 'locks'));
          rm(path.join(out, 'frontier.ndjson'));

          if (argv.dropCache === true || argv.dropCache === 'true') {
            try {
              for (const f of fs.readdirSync(out)) {
                if (/^site_catalog\.part\d+\.json$/i.test(f)) rm(path.join(out, f));
              }
            } catch {}
          }
        }

        telemetry.step('done');
        const MS = Date.now() - T0;
        const HH = Math.floor(MS/3600000);
        const MM = Math.floor((MS%3600000)/60000);
        const SS = Math.floor((MS%60000)/1000);
        console.log(`[orchestrator] done in ${HH}h ${MM}m ${SS}s (${MS.toLocaleString()} ms)`);
        try { if (global.__mc_visibleBrowser) { await global.__mc_visibleBrowser.close(); global.__mc_visibleBrowser = null; } } catch {}
        await waitForResetThenPreflight();
      }
    });
  }

  for (let i = 0; i < maxParallel; i++) launchNext();
})().catch(e => {
  console.error('orchestrator fatal:', (e && e.stack) || e);
  process.exit(1);
});

// Wait until the Telemetry UI is back in preflight (not started)
async function waitForPreflightReady() {
  const port = Number(process.env.TELEMETRY_PORT || 0);
  if (!port) return;
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  while (true) {
    try {
      const r = await fetch(`http://127.0.0.1:${port}/preflight`, { cache: 'no-store' });
      if (r.ok) {
        const j = await r.json();
        // Preflight is "ready" when started === false
        if (j && j.started === false) return;
      }
    } catch {}
    await sleep(600);
  }
}



async function waitForResetThenPreflight() {
  const port = Number(process.env.TELEMETRY_PORT || 0);
  if (!port) return;
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  let needResetAck = true;
  console.log('[orchestrator] idle — click "New Run" in the UI when ready');
  while (needResetAck) {
    try {
      const r = await fetch(`http://127.0.0.1:${port}/reset-wait`, { cache: 'no-store' });
      if (r && r.ok) needResetAck = false;
    } catch {}
    await sleep(600);
  }
  try {
    const stopFile = path.join(argv.outDir || 'dist', 'telemetry', 'stop.flag');
    if (fs.existsSync(stopFile)) fs.unlinkSync(stopFile);
  } catch {}
  await waitForPreflightReady();
}
